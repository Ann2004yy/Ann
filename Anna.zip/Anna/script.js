// Hire Me button functionality
document.getElementById('hire-btn').addEventListener('click', function() {
    alert('Thank you for your interest! Please email me at ohemaadaizy462@gmail.com to discuss opportunities.');
});
